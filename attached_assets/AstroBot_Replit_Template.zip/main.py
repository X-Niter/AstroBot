
import discord
from discord.ext import commands
import openai, os
from dotenv import load_dotenv
import anthropic
import aiohttp

load_dotenv()

intents = discord.Intents.all()
bot = commands.Bot(command_prefix="/", intents=intents)

# API keys
openai.api_key = os.getenv("OPENAI_API_KEY")
claude = anthropic.Anthropic(api_key=os.getenv("CLAUDE_API_KEY"))

@bot.event
async def on_ready():
    print(f"AstroBot is online as {bot.user}")

# GPT Command
@bot.command()
async def ask(ctx, *, prompt):
    await ctx.send("Thinking with GPT-4o...")
    response = openai.ChatCompletion.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": prompt}]
    )
    await ctx.send(response.choices[0].message.content)

# Claude Mod Idea Command
@bot.command()
async def idea(ctx, *, theme):
    msg = f"Generate a detailed Minecraft mod idea based on: {theme}"
    response = claude.messages.create(
        model="claude-3-opus-20240229",
        max_tokens=800,
        temperature=0.7,
        messages=[{"role": "user", "content": msg}]
    )
    await ctx.send(response.content[0].text)

bot.run(os.getenv("DISCORD_TOKEN"))
